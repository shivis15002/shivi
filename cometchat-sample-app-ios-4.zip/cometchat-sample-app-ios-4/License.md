Copyright (c) 2023 CometChat Inc.

License agreement: https://www.cometchat.com/legal-terms-of-service
