//  AppConstants.swift
 
//  Created by CometChat Inc. on 20/09/19.
//  Copyright ©  2020 CometChat Inc. All rights reserved.

import Foundation
import UIKit

class AppConstants {
    static var APP_ID = "<# Enter Your App ID Here #>"
    static var AUTH_KEY = "<# Enter Your AuthKey Here #>"
    static var REGION = "<# Enter Your Region Code Here #>"
}
